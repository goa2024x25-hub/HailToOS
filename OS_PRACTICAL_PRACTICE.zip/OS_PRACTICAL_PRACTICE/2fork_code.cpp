#include<iostream>
#include<unistd.h>
using namespace std;

int main(){
    pid_t pid= fork();

    if (pid==0){
        cout<<"child code: "<<getpid()<<"\n";
    }

    else{
        cout<<"parent code: "<<getpid()<<"\n";
    }

    return 0;
}
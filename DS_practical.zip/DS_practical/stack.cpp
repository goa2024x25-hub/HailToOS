#include<iostream>
#include<cstring>
#include<cctype>
using namespace std;
#define MAX 100
class Stack{
    int arr[MAX];
    int top;
public:
    Stack(){
        top=-1;
    }

    bool isEmpty(){
        return top==-1;
    }

    bool isFull(){
        return top==MAX-1;
    }

    void push(int val){
        if (isFull()){
            cout<<"stack is full"<<endl;
            return;
        }

        arr[++top]=val;
    }

    int pop(){
        if(isEmpty()){
            cout<<"stack is empty"<<endl;
            return -1;
        }

        return arr[top--];
    }

    int peek(){
        if(isEmpty()){
            cout<<"empty ";
            return -1;
        }
        return arr[top];
    }
};

//Postfix Expression Evaluation.
int postEval(string exp){
    Stack s;

    for(int i=0;i<exp.length();i++){
       char ch=exp[i];

       if(ch==' '){
        continue;
       }

       if(isdigit(ch)){
            s.push(ch-'0');
       }

       else{
            int val1=s.pop();
            int val2=s.pop();

            switch (ch)
            {
            case '+':
                s.push(val2 + val1);
                    break;
            case '-':
                s.push(val2-val1);
                    break;
            case '*':
                s.push(val2*val1);
                    break;
            case '/':
                s.push(val2/val1);
                    break;
            
            default:
                break;
            }
       
        }
    }

    return s.pop();
}

int preEval(string exp){
    Stack s;

    for(int i=exp.length()-1;i>=0;i--){
       char ch=exp[i];

       if(ch==' '){
        continue;
       }

       if(isdigit(ch)){
            s.push(ch-'0');
       }

       else{
            int val1=s.pop();
            int val2=s.pop();

            switch (ch)
            {
            case '+':
                s.push(val1 + val2);
                    break;
            case '-':
                s.push(val1-val2);
                    break;
            case '*':
                s.push(val1*val2);
                    break;
            case '/':
                s.push(val1/val2);
                    break;
            
            default:
                break;
            }
       
        }
    }

    return s.pop();
}

int main(){
    string prefix,postfix;
    
    cout<<"enter postfix expression: ";
    getline(cin,postfix);

    cout<<"postfix expression is : "<<postEval(postfix)<<endl;

    cout<<"enter prefix expression: ";
    getline(cin,prefix);

    cout<<"prefix expression is : "<<preEval(prefix)<<endl;

    return 0;
}





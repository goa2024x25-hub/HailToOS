#include<iostream>
using namespace std;
class node{
public:
    int data;
    node* next;

    node(int val){
        data=val;
        next=NULL;
    }
};
class CLL{
public:
    node* tail;
    CLL(){
        tail=NULL;
    }

    void Insert(int x){
        node* newnode=new node(x);
        if(tail==NULL){
            tail=newnode;
            newnode->next=newnode;
            return;
        }

        newnode->next=tail->next;
        tail->next=newnode;
        tail=newnode;
    }

    void Delete(int x){
        if (tail==NULL){
            cout<<"empty";
            return;
        }

        node* curr=tail->next;
        node* prev=tail;

        if(curr==tail && curr->data==x){
            delete curr;
            tail=NULL;
            return;
        }

        do{
            if(curr->data==x){
                prev->next=curr->next;
                if(curr==tail){
                    tail=prev;
                }
                delete curr;
                return;
            }
            prev=curr;
            curr=curr->next;
        }while(curr!=tail->next);
        cout<<"elemend not found.";
    }

    node* search(int x){
        if(tail==NULL){
            cout<<"empty";
            return NULL;
        }

        node* curr=tail->next;
        do{
            if (curr->data==x){
                return curr;
            }
            curr=curr->next;

        }while(curr!=tail->next);
        cout<<"element not found";

        return NULL;
    }

    void print(){
        if(tail==NULL){
            cout<<"empty";
            return;
        }
        node* curr=tail->next;
        do{
            cout<<curr->data<<"  ";
            curr=curr->next;
        }while(curr!=tail->next);
    }
};

int main(){
    CLL l;
    int choice,x;

    while(true){
        cout<<"\n1.insert\n2.delete\n3.search\n4.print\n5.exit\nChoice->";
        cin>>choice;

        switch (choice)
        {
        case 1:
            cout<<"enter value : ";
            cin>>x;
            l.Insert(x);
            break;
        case 2:
            cout<<"enter value : ";
            cin>>x;
            l.Delete(x);
            break;
        case 3:
            cout<<"enter value : ";
            cin>>x;
            if(node* ptr = l.search(x)){
                cout<<"address of node : "<<ptr;
            }    
            else{
                cout<<"node not found.";
            }
            break;
        case 4:
            l.print();
            break;
        case 5:
            return 0;
        default:
            cout<<"invalid choice.";
            break;
        }
    }

    return 0;
};






#include<iostream>
using namespace std;

class node{
public:
    int data;
    node* prev;
    node* nxt;

    node(int val){
        data=val;
        prev=nxt=NULL;
    }
};

class DLL{
public:
    node* head;

    DLL(){
        head=NULL;
    }

    void IAB(int val){
        node* newnode=new node(val);
        if(head==NULL){
            head=newnode;
            return;
        }
        else{
            newnode->nxt=head;
            head->prev=newnode;
            head=newnode; 
        }
    }

    void IAE(int val){
        node* newnode=new node(val);

        if(head==NULL){
            head=newnode;
            return;
        }

        node* temp=head;
        while(temp->nxt!=NULL){
            temp=temp->nxt;
        }

        temp->nxt=newnode;
        newnode->prev=temp;

    }

    void DAB(){
        if(head==NULL){
            cout<<"empty";
            return;
        }
        node* temp=head;

        if(head->nxt==NULL){
            head=NULL;
        }else{
            head=head->nxt;
            head->prev=NULL;
        }
        delete temp;
    }

    void DFE(){
        if (head==NULL){
            cout<<"empty";
            return;
        }
        node* temp=head;
        if(temp->nxt==NULL){
            head=NULL;
            delete temp;
            return;
        }

        while(temp->nxt!=NULL){
            temp=temp->nxt;
        }

        temp->prev->nxt=NULL;
        delete temp;
    }

    void print(){
        node* temp=head;
        while(temp!=NULL){
            cout<<temp->data<<"  ";
            temp=temp->nxt;
        }
    }
};
int main(){
    DLL l;
    int x,choice;
    
    while(true){
        cout<<"\n1.IAB\n2.IAE\n3.DAB\n4.DFE\n5.print...\n6.Exit...";
        cout<<"\nChoice-->";
        cin>>choice;

        switch (choice)
        {
        case 1:
            cout<<"enter value : ";
            cin>>x;
            l.IAB(x);
            break;
            
        case 2:
            cout<<"enter value : ";
            cin>>x;
            l.IAE(x);
            break;
        case 3:
            l.DAB();
            break;
        case 4:
            l.DFE();
            break;
        case 5:
            l.print();
            break;
        case 6:
            return 0;
        default:
            cout<<"\ninvalid choice";
            
        }
    }

}


        



            




#include<iostream>
using namespace std;
class Node{
    public:
        int data;
        Node* next;

        Node(int val){
            data=val;
            next=NULL;
        }
};

class SLL{
    public:
        Node* head;
        SLL(){
            head=NULL;
        }
        //1.
        void IAB(int val){
            Node* newnode=new Node(val);
            newnode->next=head;
            head=newnode;
        }
        //2.
        void IAP(int val, int pos){

            if (pos==0){
                IAB(val);
                return;
            }

            Node* newnode = new  Node(val);
            Node* temp=head;
            for(int i=0;temp!=NULL && i<pos-1;i++){
                temp=temp->next;
            }

            if(temp==NULL){
                cout<<"out of bound";
                delete newnode;
                return;
            }

            newnode->next=temp->next;
            temp->next=newnode;

        }
        //3.
        void DFB(){
            if (head==NULL){
                cout<<"empty list";
                return;
            }

            Node* temp=head;
            head=head->next;
            delete temp;
        }
        //4.
        void DFP(int pos){
            if (head==NULL){
                cout<<"out of bound";
                return;
            }

            if(pos==0){
                DFB();
                return;
            }

            Node* temp=head;
            for(int i=0;temp!=NULL && i<pos-1;i++){
                temp=temp->next;
            }

            if (temp==NULL || temp->next==NULL){
                cout<<"out of bound";
                return;
            }

            Node* ToDelete = temp->next;
            temp->next=temp->next->next;
            delete ToDelete;
        }

        Node* search(int val){
            Node* temp=head;
            while(temp!=NULL){
                if(temp->data==val){
                    cout<<temp->data;
                }
                temp=temp->next;
            }
            return NULL;
        }

        void print(){
            Node* temp=head;
            while(temp!=NULL){
                cout<<temp->data<<"  ";
                temp=temp->next;
            }
            cout<<"\n";
            

        }
};

int main(){
    SLL l;
    int choice,x,pos;
    while(true){
        cout<<"\n1.IAB\n2.IAP\n3.DFB\n4.DFP\n5.search\n6.print\n7.exit...";
        cout<<"\nyour choice->";
        cin>>choice;

        
        switch(choice){
            case 1:
                cout<<"enter value";
                cin>>x;
                l.IAB(x);
                break;
            case 2:
                cout<<"enter val";
                cin>>x;
                cout<<"Enter position";
                cin>>pos;
                l.IAP(x,pos);
                break;
            case 3:
                l.DFB();
                break;
            case 4:
                cout<<"enter position";
                cin>>pos;
                l.DFP(pos);
                break;
            case 5:
                if(Node* ptr =l.search(x)){
                    cout<<"address of node: "<<ptr;
                }
                else
                    cout<<"nodde not found:";
                    break;
            case 6:
                    cout<<"List:";
                    l.print();
                    break;
            case 7:
                    return 0;
            default:
                    cout<<"\ninvalid choice ";
            }
    }
            
};
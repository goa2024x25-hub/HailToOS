#include <iostream>
using namespace std;

class Node {
public:
    int val;           // value stored
    Node *left;
    Node *right;
    int height;        // height of node

    Node(int v) {
        val = v;
        left = right = NULL;
        height = 1;
    }
};

// Get height of a node
int getHeight(Node* n) {
    if (n == NULL) return 0;
    return n->height;
}

// Get balance factor of node
int getBalance(Node* n) {
    if (n == NULL) return 0;
    return getHeight(n->left) - getHeight(n->right);
}

// Right Rotation
Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    // Rotate
    x->right = y;
    y->left = T2;

    // Update heights
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;

    return x; // new root
}

// Left Rotation
Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    // Rotate
    y->left = x;
    x->right = T2;

    // Update heights
    x->height = max(getHeight(x->left), getHeight(x->right)) + 1;
    y->height = max(getHeight(y->left), getHeight(y->right)) + 1;

    return y; // new root
}

// Insert value in AVL Tree
Node* insertNode(Node* root, int val) {

    // 1. Normal BST insert
    if (root == NULL)
        return new Node(val);

    if (val < root->val)
        root->left = insertNode(root->left, val);
    else if (val > root->val)
        root->right = insertNode(root->right, val);
    else
        return root;  // duplicate not allowed

    // 2. Update height
    root->height = 1 + max(getHeight(root->left), getHeight(root->right));

    // 3. Get balance factor
    int balance = getBalance(root);

    // 4. 4 cases of rotation

    // Left Left Case
    if (balance > 1 && val < root->left->val)
        return rightRotate(root);

    // Right Right Case
    if (balance < -1 && val > root->right->val)
        return leftRotate(root);

    // Left Right Case
    if (balance > 1 && val > root->left->val) {
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    // Right Left Case
    if (balance < -1 && val < root->right->val) {
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }

    return root;
}

// Search operation in AVL
bool searchNode(Node* root, int val) {
    if (root == NULL) return false;

    if (root->val == val) return true;

    if (val < root->val)
        return searchNode(root->left, val);
    else
        return searchNode(root->right, val);
}

// Print inorder (sorted)
void inorder(Node* root) {
    if (root == NULL) return;
    inorder(root->left);
    cout << root->val << " ";
    inorder(root->right);
}

int main() {
    Node* root = NULL;
    int choice, val;

    while (true) {
        cout << "\n1. Insert\n2. Search\n3. Print (Inorder)\n4. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value to insert: ";
            cin >> val;
            root = insertNode(root, val);
            break;

        case 2:
            cout << "Enter value to search: ";
            cin >> val;
            if (searchNode(root, val))
                cout << "Found!\n";
            else
                cout << "Not Found!\n";
            break;

        case 3:
            cout << "Inorder Traversal: ";
            inorder(root);
            cout << endl;
            break;

        case 4:
            return 0;

        default:
            cout << "Invalid choice!\n";
        }
    }
}

#include<iostream>
using namespace std;
#define MAX 100
class Queue{
    int arr[MAX];
    int front, rear;
public:
    Queue(){
        rear=-1;
        front=-1;
    }

    bool isEmpty(){
        return (front==-1);
    }
    bool isFull(){
        return (rear==MAX-1);
    }

    void enqueue(int x){
        if (isFull()){
            cout<<"queue is full.";
            return;
        }

        if(front==-1){
            front=0;
        }

        arr[++rear]=x;
    }

    int dequeue(){
        if(isEmpty()){
            cout<<"empty queue";
            return -1;
        }

        int val=arr[front];
        front++;
        
        if(front>rear){
            front=rear=-1;
        }

        return val;
    }

    int peek(){
        if(isEmpty()){
            cout<<"queue empty";
            return -1;
        }

        return arr[front];
    }

    void display(){
        if(isEmpty()){
            return ;
        }

        for(int i=front;i<=rear;i++){
            cout<<arr[i]<<" ";
        cout<<endl;
        }
    }
};

int main(){
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.enqueue(40);

    q.display();

    cout<<"Dequeued: "<<q.dequeue()<<endl;
    q.display();

    return 0;
}




